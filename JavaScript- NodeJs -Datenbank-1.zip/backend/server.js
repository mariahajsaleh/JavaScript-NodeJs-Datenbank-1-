const express = require("express");
const app = express();
 
const cors = require("cors"); // Cors ist eine Funktion
app.use(cors());
 
const sqlite3 = require("sqlite3");
 
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 * Verbindung zum Datenbank-Datei aufbauen
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
 
let db = new sqlite3.Database("./imbissBude.db", (fehler) => {
  if (fehler) console.error(fehler.message);
  else
    console.log("Verbindung zum Datenbank test.db erfolgreich aufgebaut :-)");
});
 
const PortNummer = 8087;
 
app.get("/abruf/produkt/tabelle", (req, res) => {
  db.all(`SELECT * FROM Produkte`, (fehler, zeilen) => {
    res.send(JSON.stringify(zeilen));
  });
});
 
//----
 
app.get("/login/:u/:p", (req, res) => {
  db.all(
    `SELECT * FROM Verwaltung
      WHERE EINTRAG1 = 'adminUser'
      AND EINTRAG2 = 'adminKonto'
      AND WERT = '${req.params.u},${req.params.p}'`,
    (fehler, zeilen) => {
      res.send(zeilen.length > 0 ? "1" : "0");
    }
  );
});
//----
app.get("/bestellungen", (req, res) => {
  db.all(`SELECT * FROM Bestellungen`, (fehler, zeilen) => {
    res.send(JSON.stringify(zeilen));
  });
});
 
//----
app.get("/warenkorb/neu/:d/:k", (req, res) => {
  const D = req.params.d;
  const K = JSON.parse(req.params.k);
console.log(D,K);
  db.run(
    `INSERT INTO Bestellungen
 
      ( Details , Netto , MwSt , Brutto )
 
      VALUES
 
      ( '${D}', '${K.netto}', '${K.mwst}', '${K.brutto}' )`,
 
    (fehler) => console.error(fehler)
  );
 
  res.send("ok");
});
 

 
//waren Bestelldetail...
app.get("/waren/bestelldetail/:BeNr", (req,res) =>{
  db.all(`SELECT Details FROM Bestellungen WHER BestellNr='${req.params.BeNr}' `,
  (fehler, zeile) =>{
    if (fehler) {
      console.error(fehler);
      res.status(500).json({ error: "Fehler"});
    }else {
      res.send(zeile);
    }
  });
});
 
app.get("/abruf/datenschutz", (req, res) => {
  db.all(
    `SELECT * FROM Verwaltung WHERE  EINTRAG1 = 'Datenschutz'`,
 
    (fehler, zeilen) => {
      res.send(JSON.stringify(zeilen));
    }
  );
});
 
//----
 
app.get("/abruf/impressum/", (req, res) => {
  db.all(
    `SELECT  WERT FROM Verwaltung WHERE  EINTRAG1 = 'Impressum'`,
 
    (fehler, zeilen) => {
      res.send(JSON.stringify(zeilen));
    }
  );
});
 
//----
 
app.get("/ablegen/kontakt/:objekt", (req, res) => {
  const o = JSON.parse(req.params.objekt);
 
  db.run(
    `INSERT INTO KontaktAnfragen
 
      ( Vorname , Nachname , Telefon , Email , Nachricht )
 
      VALUES
 
      ( '${o.Vorname}', '${o.Nachname}', '${o.Telefon}', '${o.Email}', '${o.Nachricht}' )`,
 
    (fehler) => console.error(fehler)
  );
 
  res.send("ok");
});
 
//----
 
app.get("/abruf/angebot/tabelle", (req, res) => {
  db.all(`SELECT * FROM Angebote`, (fehler, zeilen) => {
    res.send(JSON.stringify(zeilen));
  });
});
 
//----
 
app.get("/admin/produkt/aendern/:name/:preis/:ProdID", (req, res) => {
  const o = req.params;
  db.run(
    `UPDATE  Produkte  SET
    Produktname = '${o.name}',
    Preis = '${o.preis}'
     WHERE ProdID = '${o.ProdID}'`,
    (fehler) => console.error(fehler)
  );
 
  res.send("OK");
});
 
//----
 
app.get("/admin/produkt/neu/:name/:preis", (req, res) => {
  const o = req.params;
 
  db.run(
    `INSERT INTO Produkte
 
  ( Produktname , Preis)
 
  VALUES
 
  ( '${o.name}', '${o.preis}' )`,
 
    (fehler) => console.error(fehler)
  );
 
  res.send("ok");
});
 
//----
 
app.get("/admin/produkt/entf/:ProdID", (req, res) => {
  db.all(` DELETE FROM Produkte WHERE ProdID ='${req.params.ProdID}'`);
 
  res.send("ok");
});
 
//----
 
app.get("/admin/angebot/aendern/:titel/:objekt/:angId", (req, res) => {
  const o = req.params;
  db.run(
    `UPDATE  Angebote  SET
    Angebotsname = '${req.params.titel}',
    Daten = '${JSON.stringify(req.params.objekt)}'
     WHERE AngID = ${req.params.angId}`,
    (fehler) => console.error(fehler)
  );
 
  res.send("OK");
});
 
//----
 
app.get("/admin/angebot/neu/:titel/:preis/:objekt", (req, res) => {
  db.run(
    `INSERT INTO Angebote  
 
  ( Angebotsname  , Preis , Daten)
 
  VALUES
 
  ( '${req.params.titel}', '${req.params.preis}' , '${JSON.stringify(
      req.params.objekt
    )}' )`,
 
    (fehler) => console.error(fehler)
  );
 
  res.send("ok");
});
 
//----
 
app.get("/admin/angebot/entf/:angId", (req, res) => {
  db.all(` DELETE FROM Angebote WHERE AngID ='${req.params.angId}'`);
 
  res.send("ok");
});
 
//----
 
app.get("/admin/kontakt/abruf", (req, res) => {
  db.all(`SELECT * FROM KontaktAnfragen`, (fehler, zeilen) => {
    res.send(JSON.stringify(zeilen));
  });
});
 
//----
 
app.get("/admin/kontaktt/entf/:kaID", (req, res) => {
  db.all(` DELETE FROM KontaktAnfragen WHERE KAID ='${req.params.kaID}'`);
 
  res.send("ok");
});
app.get("/admin/socialMedia/lesen/:id", (req, res) => {
  db.all(`SELECT * FROM Verwaltung
          WHERE EINTRAG1 = 'SocialMedia-${req.params.id}'`,
        (fehler, zeile) => {
          res.send(zeile[0].WERT);
        });
});

///admin/datenschutz/lesen/
app.get("/admin/datenschutz/lesen/", (req, res) => {
  db.all(`SELECT * FROM Verwaltung
          WHERE EINTRAG1 = 'Datenschutz'`,
        (fehler, zeile) => {
          res.send(zeile[0].WERT);
        });
});
////admin/impressum/lesen/
app.get("/admin/impressum/lesen/", (req, res) => {
  db.all(`SELECT * FROM Verwaltung
          WHERE EINTRAG1 = 'Impressum'`,
        (fehler, zeile) => {
          res.send(zeile[0].WERT);
        });
});

app.get("/admin/socialMedia/aendern/:id/:wert", (req, res) => {
  const o = req.params;
  const e = o.id.toUpperCase();
  let sqlcode = "";
  // *** //
  switch (e) {
    case "X":
      sqlcode = `UPDATE Verwaltung SET
               WERT = '${o.wert}'
               WHERE EINTRAG1 = 'SocialMedia-${e}'`;
      break;
    case "F":
      sqlcode = `UPDATE Verwaltung SET
                WERT = '${o.wert}'
                WHERE EINTRAG1 = 'SocialMedia-${e}'`;
      break;
    case "G":
      sqlcode = `UPDATE Verwaltung SET
                WERT = '${o.wert}'
                WHERE EINTRAG1 = 'SocialMedia-${e}'`;
      break;
    case "L":
      sqlcode = `UPDATE Verwaltung SET
                 WERT = '${o.wert}'
                 WHERE EINTRAG1 = 'SocialMedia-${e}'`;
      break;
  }
  // *** //
  db.run( sqlcode,
    (fehler) => console.error(fehler)
  );
 
  res.send("OK");
});
 
//----
 
app.get("/admin/aendern/d/:text", (req, res) => {
  const o = req.params;
  db.run(
    `UPDATE Verwaltung SET
    WERT = '${o.text}'
    WHERE EINTRAG1 = 'Datenschutz'`,
    (fehler) => console.error(fehler)
  );
 
  res.send("OK");
});
 
//----
 
app.get("/admin/aendern/i/:text", (req, res) => {
  const o = req.params;
  db.run(
    `UPDATE Verwaltung SET
    WERT = '${o.text}'
    WHERE EINTRAG1 = 'Impressum'`,
    (fehler) => console.error(fehler)
  );
 
  res.send("OK");
});
 
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 * Der eigentliche Server ist ein Unterprogramm der ständig den angegebenen Port überprüft,
 * und schaut, ob eine Anfrage (request) angekommen ist. Wenn ja, wird die Anfrage an
 * die Routen weitergeleitet.
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
 
const server = app.listen(
  PortNummer, // Die Portnummer, die abgehört werden soll
  () =>
    // Die Callback-Funktion, die aufgerufen wird, wenn was reinkommt
    {
      // Beispiel auf Konsole
      console.log(`Server horcht nach http://localhost:${PortNummer}/`);
    }
);
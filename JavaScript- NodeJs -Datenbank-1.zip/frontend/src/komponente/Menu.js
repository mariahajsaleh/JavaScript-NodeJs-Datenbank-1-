import React, {useEffect, useState} from "react";
import "./Menu.css";
import { Link, Outlet } from "react-router-dom";
import Startseite from "./Startseite";
import AdminSocialMedia from "./AdminSocialMedia";
export default function Menu() {
const [adminStatus, adminStatusUpdate] = useState(false);
const [facebook,facebookUpdate] =useState("");
const [twitter,twitterUpdate] =useState("");
const [linkedin,linkedinUpdate] =useState("");
const [instagram,instagramUpdate] =useState("");
const [logo,logoUpdate] =useState("");


  useEffect(() => {
    let a = sessionStorage.getItem("adminStatus");
    adminStatusUpdate(a === "1" ? true : false);
    facebookUpdate("https://de-de.facebook.com/");
    twitterUpdate("https://twitter.com/");
    linkedinUpdate("https://www.linkedin.com/");
    instagramUpdate("https://www.instagram.com/");
  }, []);

  return (
    <>
      {adminStatus === false ? (
        <header>
           <img src="logom.png" alt="logo" />
          <Link to="/">Startseite</Link>
          <Link to="/angebote">Angebote</Link>
          <Link to="/warenkorb">Warenkorb</Link>

         
        </header>
      ) : (
        <header>
           <img src="logom.png" alt="logo" />
          <Link to="/">Bestellungen</Link>   
          <Link to="/admin/produkte">Produkte</Link>
          <Link to="/admin/agebote">Angebote</Link>
          <Link to="/admin/anfragen">Anfragen</Link>
          <Link to="/admin/socialMedia">Social Media</Link>
          <Link to="/logout"><b>Abmelden</b></Link>
        
          </header>
      )}
      <main>
        <Outlet />
      </main>
      {adminStatus ===false ? (<footer>
        <div>
        <a href ={twitter} target ="_blank">
            <img src="x.png" alt="twitter" />
          </a>
          <a href ={facebook} target ="_blank">
            <img src="facebook.png" alt="facebook" />
          </a>
          <a href ={instagram} target ="_blank">
            <img src="instagram.png" alt="instagram" />
          </a>
          <a href ={linkedin} target ="_blank">
            <img src="linkedin.png" alt="linkedin" />
          </a>
        </div>
        <div>
        <Link to="/kontakt">Kontakt</Link>
          <Link to="/impressum">Impressum</Link>
          <Link to="/datenschutz">Datenschutz</Link>
          </div>
          
      </footer>):(<footer>
        
        <div>
        <a href ={twitter} target ="_blank">
            <img src="x.png" alt="twitter" />
          </a>
          <a href ={facebook} target ="_blank">
            <img src="facebook.png" alt="facebook" />
          </a>
          <a href ={instagram} target ="_blank">
            <img src="instagram.png" alt="instagram" />
          </a>
          <a href ={linkedin} target ="_blank">
            <img src="linkedin.png" alt="linkedin" />
          </a>
        </div>
        <div>
        <Link to="/admin/impressum">Impressum</Link>
        <Link to="/admin/datenschutz">Datenschutz</Link>
        </div>
        </footer>)}
        
    </>
  );
}
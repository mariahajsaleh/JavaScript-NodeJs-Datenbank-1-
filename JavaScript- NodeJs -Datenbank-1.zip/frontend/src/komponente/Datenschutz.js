import React, { useEffect, useState } from "react";

function DatenschutzText({ Daten }) {
 
  const [daten, datenUpdate] = useState("");
 
  
  useEffect(() => {
  
      datenUpdate(Daten.Wert);
    
  }, [Daten]);
  return (
    <>
    {Daten.WERT}
    </>
  );
}

export default function Datenschutz() {
  const [adminStatus, adminStatusUpdate] = useState(false);
  const [text,textUpdate]= useState("");
  const [datenschutzText, setDatenschutzText] = useState('');
  //
  function readJSONFromServer(u, cb) {
    // Anfrage an den Server scihcken
 
    window
 
      .fetch(u)
 
      // Antwort erhalten und als JSON-Objekt weiterreichen
 
      .then((rohdaten) => rohdaten.json())
 
      // Die weitergereichte Information an die Callback-Funktion übergeben
 
      .then((daten) => cb(daten))
 
      // Falls ein Fehler aufteten sollte, diese auf der Konsole ausgegeben
 
      .catch((fehler) => console.error(fehler));
  }
  function readTEXTFromServer(u, cb) {

    // Anfrage an den Server scihcken

    window

      .fetch(u)

      // Antwort erhalten und als Text weiterreichen

      .then((rohdaten) => rohdaten.text())

      // Die weitergereichte Information an die Callback-Funktion übergeben

      .then((daten) => cb(daten))

      // Falls ein Fehler aufteten sollte, diese auf der Konsole ausgegeben

      .catch((fehler) => console.error(fehler));

  }
 
  function aktualisiereInhalt() {
    readJSONFromServer(
      "http://localhost:8087/abruf/datenschutz/",
      (zeilen) => {
        if(typeof zeilen === "object" && zeilen.length > 0)
        {
          const htmlCode = [];
 
          // *** //
          zeilen.forEach((zeile) => {
            htmlCode.push(
              <>
                <DatenschutzText Daten={zeile} />
              </>
            );
          });
 
          // *** //
 
          textUpdate(htmlCode);  
        }
      }
    );
   
  }
  useEffect(() => {
    aktualisiereInhalt();
  }, []);
  
    return (
  
      <>
  
    {text}
  
      </>
  
    );
  }
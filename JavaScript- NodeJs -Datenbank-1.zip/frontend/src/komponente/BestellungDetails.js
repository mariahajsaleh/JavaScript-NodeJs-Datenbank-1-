import React, { useState, useEffect } from "react";
import { decodeText } from "./encodeDecode";
 
export default function BestellungDetails({ Daten }) {
  const [Datum, DatumNeu] = useState(new Date());
  const [DetailInfo, DetailInfoNeu] = useState("Klicke auf Details...");
  const [DetailStatus, DetailStatusNeu] = useState(false);
  const [versteckteDaten, versteckeDatenNeu] = useState({});
 
  useEffect(() => versteckeDatenNeu(Daten), []);
 
  function details(beNo) {
    console.log("test");
    if (DetailStatus == false) {
      let d = JSON.parse(decodeText(versteckteDaten.Details));
      // *** //
      let sammeln = [];
      // *** //
      console.log(d);
      console.log(d.length);
      d.forEach((eintrag) => {
        sammeln.push(
          <tr>
            <td>{eintrag.Typ === "P" ? "Produkt" : "Angebot"}</td>
            <td>{eintrag.Name}</td>
            <td>{eintrag.Menge}</td>
            <td>{eintrag.Preis * eintrag.Menge}</td>
          </tr>
        );
      });
      console.log(sammeln);
      // *** //
      DetailInfoNeu(
        <tr id={beNo}>
          <td colSpan="4" style={{ backgroundColor: "silver" }}>
            {typeof d === "object" ? <table>{sammeln}</table> : <></>}
          </td>
        </tr>
      );
      DetailStatusNeu(true);
    } else if (DetailStatus == true) {
      DetailInfoNeu("Klicke auf Details...");
      DetailStatusNeu(false);
    }
  }
 
  return (
    <>
      <tr>
        <td>
          <p>
            <b>{versteckteDaten.BestellNr}</b>
          </p>
        </td>
        <td>
          <p>{Datum.toLocaleDateString("de-DE")}</p>
        </td>
        <td>
          <p>
            <u>{versteckteDaten.Brutto}</u>
          </p>
        </td>
        <td>
          <button onClick={() => details(versteckteDaten.BestellNr)}>
            Details
          </button>
        </td>
      </tr>
      {DetailInfo}
    </>
  );
}
import React, {useState} from "react";
import "./Kontakt.css";

export default function Kontakt() {

  const [vorname, vornameUpdate] =useState("");
  const [nachname, nachnameUpdate] =useState("");
  const [email, emailUpdate] =useState("");
  const [telefon, telefonUpdate] =useState("");
  const [nachricht, nachrichtUpdate] =useState("");

 
  function readTEXTFromServer(u, cb) {

    // Anfrage an den Server scihcken

    window

      .fetch(u)

      // Antwort erhalten und als Text weiterreichen

      .then((rohdaten) => rohdaten.text())

      // Die weitergereichte Information an die Callback-Funktion übergeben

      .then((daten) => cb(daten))

      // Falls ein Fehler aufteten sollte, diese auf der Konsole ausgegeben

      .catch((fehler) => console.error(fehler));

  }
  function readJSONFromServer(u, cb) {

    // Anfrage an den Server scihcken

    window

      .fetch(u)

      // Antwort erhalten und als JSON-Objekt weiterreichen

      .then((rohdaten) => rohdaten.json())

      // Die weitergereichte Information an die Callback-Funktion übergeben

      .then((daten) => cb(daten))

      // Falls ein Fehler aufteten sollte, diese auf der Konsole ausgegeben

      .catch((fehler) => console.error(fehler));

  }



  function senden(){
    const objekt ={
      Vorname:vorname.value,
      Nachname:nachname.value,
      Telefon: telefon.value ,
      Email:email.value,
      Nachricht :nachricht.value
    };
    readTEXTFromServer(
      "http://localhost:8087/ablegen/kontakt/"+
      JSON.stringify(objekt),
      (antwort)  => {
        vorname.value ="";
        nachname.value="";
        telefon.value ="";
        email.value="";
        nachricht.value="";
      } 

    );
  }
 
    return (
  
      <>
  
    <div >
      <div className="form">
<label>Vorname</label>
<input type="text" placeholder="Vorname" 
  onKeyUp={(e) => vornameUpdate(e.target)}/>
  </div>

  <div className="form">
  <label>Nachname</label>
<input type="text" placeholder="Nachname" 
  onKeyUp={(e) => nachnameUpdate(e.target)}/>
  </div>
 <div className="form">
  <label>Email</label>
<input type="text" placeholder="Email" 
  onKeyUp={(e) => emailUpdate(e.target)}/>
  </div>
 <div className="form">
  <label>Telefon</label>
<input type="number" placeholder="Telefon" 
  onKeyUp={(e) => telefonUpdate(e.target)}/>
  </div>
 <div className="form">
  <label>Nachricht</label>
<textarea  placeholder="Nachricht" 
  onKeyUp={(e) => nachrichtUpdate(e.target)}>
  </textarea>
  </div>
  <div className="form">
  <button onClick={() => senden()}>Senden</button>
  </div>
    </div>
  
      </>
  
    );
  }
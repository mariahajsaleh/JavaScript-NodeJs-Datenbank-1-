import React, { useEffect, useState } from "react";
import ZugriffVerweigert from "./ZugriffVerweigert";

export default function AdminImpressum() {
  const [adminStatus, adminStatusUpdate] =useState(false); 
  const [impressumText, setImpressumText] = useState('');
  const [state, setState] = useState(false);
 


  function readTEXTFromServer(u, cb) {

    // Anfrage an den Server scihcken

    window

      .fetch(u)

      // Antwort erhalten und als Text weiterreichen

      .then((rohdaten) => rohdaten.text())

      // Die weitergereichte Information an die Callback-Funktion übergeben

      .then((daten) => cb(daten))

      // Falls ein Fehler aufteten sollte, diese auf der Konsole ausgegeben

      .catch((fehler) => console.error(fehler));

  }

  useEffect(() => {
    const a = sessionStorage.getItem("adminStatus");
    adminStatusUpdate(a=== "1" ? true : false);
    readTEXTFromServer("http://localhost:8087/admin/impressum/lesen/",
     (antwort)=>setImpressumText(antwort));

  },[]);

  function speichern() {

    readTEXTFromServer("http://localhost:8087/admin/aendern/i/" + impressumText ,
      (antwort) => {
        let r=impressumText;
        if(r)
        readTEXTFromServer(impressumText, (antwort) => {
          setState(true);
       } );
        
      });
  }
    return (
      <>
  {adminStatus === false ?
  (<ZugriffVerweigert />):(
    <div>
    <textarea
        placeholder="Impressum ..."
        defaultValue={impressumText}
     onKeyUp={e => setImpressumText(e.target.value)}
    />
    <button onClick={() => speichern()}>Ändern</button>
  </div>
  )}
  {state && <p>Aktualisierung erfolgreich!</p>}
 </>
  
    );
  }
import React, {useEffect} from "react";

export default function Logout() {

  useEffect(

    () => {

      sessionStorage.removeItem("adminStatus");

      //  window.setTimeout(

        //    () => {

                window.location.href = "http://localhost:3000/";

          //  },

        //    1000

     //   );

    },

    []

);

// *** //

return (

    <>

<h2>Bis Bald</h2>

    </>

)
  }
import React, { useState } from "react";

export default function Login() {
  const [loginBenutzer, loginBenutzerUpdate] = useState("");

  const [loginKennwort, loginKennwortUpdate] = useState("");
  const [fehler, fehlerUpdate] = useState("");

  // *** //

  const [loginInfo, loginInfoUpdate] = useState("");
  function readTEXTFromServer(u, cb) {

    // Anfrage an den Server scihcken

    window

      .fetch(u)

      // Antwort erhalten und als Text weiterreichen

      .then((rohdaten) => rohdaten.text())

      // Die weitergereichte Information an die Callback-Funktion übergeben

      .then((daten) => cb(daten))

      // Falls ein Fehler aufteten sollte, diese auf der Konsole ausgegeben

      .catch((fehler) => console.error(fehler));

  }

  // *** //

  const einloggen = () => {

    // 

    readTEXTFromServer(

      "http://localhost:8087/login/" + loginBenutzer + "/" + loginKennwort,

      (antwort) => {

        sessionStorage.setItem("adminStatus", antwort);


        if (antwort == "1")
          window.location.href = "http://localhost:3000/";
        else
          fehlerUpdate(<div>Benutzername oder Kennwort falsch!</div>)

      }

    );

  };


  return (

    <>
      <div className="formularKasten">
        {fehler}


        <h3>Einloggen</h3>

        <input

          type="text"

          placeholder="Benutzer"

          onKeyUp={(e) => loginBenutzerUpdate(e.target.value)}

        />

        <br />

        <input

          type="password"

          placeholder="Kennwort"

          onKeyUp={(e) => loginKennwortUpdate(e.target.value)}

        />

        <br />

        <button onClick={einloggen}>Anmelden</button>

      </div>

    </>

  );
}
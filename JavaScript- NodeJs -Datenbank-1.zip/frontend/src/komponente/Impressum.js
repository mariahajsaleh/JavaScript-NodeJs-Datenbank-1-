import React, { useEffect, useState } from "react";


function ImpressumText({ Daten }) {
 
  const [daten, datenUpdate] = useState("");
 
  
  useEffect(() => {
  
      datenUpdate(Daten.Wert);
    
  }, [Daten]);
  return (
    <>
    {Daten.WERT}
    </>
  );
}


export default function Impressum() {

  const [text,textUpdate]= useState("");
   

  function readJSONFromServer(u, cb) {
    // Anfrage an den Server scihcken
 
    window
 
      .fetch(u)
 
      // Antwort erhalten und als JSON-Objekt weiterreichen
 
      .then((rohdaten) => rohdaten.json())
 
      // Die weitergereichte Information an die Callback-Funktion übergeben
 
      .then((daten) => cb(daten))
 
      // Falls ein Fehler aufteten sollte, diese auf der Konsole ausgegeben
 
      .catch((fehler) => console.error(fehler));
  }
  //

  function aktualisiereInhalt() {
    readJSONFromServer(
      "http://localhost:8087/abruf/impressum/",
      (zeilen) => {
        if(typeof zeilen === "object" && zeilen.length > 0)
        {
          const htmlCode = [];
 
          // *** //
          zeilen.forEach((zeile) => {
            htmlCode.push(
              <>
                <ImpressumText Daten={zeile} />
              </>
            );
          });
 
          // *** //
 
          textUpdate(htmlCode);  
        }
      }
    );
  }


  useEffect(() => {
    aktualisiereInhalt();
  }, []);
  


    return (
  
      <>
  
    {text}
  
      </>
  
    );
  }
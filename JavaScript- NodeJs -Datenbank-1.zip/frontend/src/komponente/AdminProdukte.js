import React, { useEffect, useState } from "react";
import ZugriffVerweigert from "./ZugriffVerweigert";


export default function AdminProdukte() {
  const [adminStatus, adminStatusUpdate] = useState(false);
 
  const [produkte, produkteUpdte] = useState([]);
  const [name, nameUpdate] = useState("");
  const [preis, preisUpdate] = useState("");
  //
  function readTEXTFromServer(u, cb) {

    // Anfrage an den Server scihcken

    window

      .fetch(u)

      // Antwort erhalten und als Text weiterreichen

      .then((rohdaten) => rohdaten.text())

      // Die weitergereichte Information an die Callback-Funktion übergeben

      .then((daten) => cb(daten))

      // Falls ein Fehler aufteten sollte, diese auf der Konsole ausgegeben

      .catch((fehler) => console.error(fehler));

  }
  function readJSONFromServer(u, cb) {

    // Anfrage an den Server scihcken

    window

      .fetch(u)

      // Antwort erhalten und als JSON-Objekt weiterreichen

      .then((rohdaten) => rohdaten.json())

      // Die weitergereichte Information an die Callback-Funktion übergeben

      .then((daten) => cb(daten))

      // Falls ein Fehler aufteten sollte, diese auf der Konsole ausgegeben

      .catch((fehler) => console.error(fehler));

  }
  function produkteLaden() {
    readJSONFromServer("http://localhost:8087/abruf/produkt/tabelle", (antwort) => {
      const daten = [];
      antwort.forEach((zeile) => {
        let ID1 = "feldA" + zeile.ProdID;
        let ID2 = "feldB" + zeile.ProdID;
        daten.push(
          <>
          <p>
            <input type="text" defaultValue={zeile.Produktname} placeholder="Produkt" id={ID1} />
            <input type="number" defaultValue={zeile.Preis} placeholder="Preis.." id={ID2} />
            <button onClick={() => speichern(ID1, ID2, zeile.ProdID)}>Ändern</button>
            <button onClick={() => entfernen(zeile.ProdID)}>Entferfen</button>
            </p>
          </>)
      });
      produkteUpdte(daten);
    })
  }
  function hinzufugen() {
    readTEXTFromServer(

      "http://localhost:8087/admin/produkt/neu/" +

      name.value + "/" +

      preis.value ,

      (e) => {
        name.value="";
        preis.value="";

        nameUpdate("");

        preisUpdate("");
       
     

        produkteLaden();
      }

    );
  }
  function speichern(a, b, c) {
    const pn = document.getElementById(a).value;
    const pp = document.getElementById(b).value;
    const id = c;
    readTEXTFromServer("http://localhost:8087/admin/produkt/aendern/" + pn + "/" + pp + "/" + id,
      (antwort) => {
        alert("Änderungen wueden gespeichert! ");
      });
  }

  function entfernen(id) {

    readTEXTFromServer("http://localhost:8087/admin/produkt/entf/"  + id,
      (antwort) => {
        produkteLaden();
        alert("Produkt wurde entfernt! ");
      
      });
  }

  useEffect(() => {
    const a = sessionStorage.getItem("adminStatus");
    adminStatusUpdate(a === "1" ? true : false);
    produkteLaden();
  }, []);

  return (
    <>
      {adminStatus === false ?
        (<ZugriffVerweigert />) : (
          <>
            {produkte}
            <h3>Neues Produkt</h3>

            <input type="text" placeholder="Produkt" onKeyUp={(e) => nameUpdate(e.target) }id ="a"/>
            <input type="number" placeholder="Preis.." onKeyUp={(e) => preisUpdate(e.target)} id ="b" />
            <button onClick={() => hinzufugen()}>Hinzufügen</button>
           
          </>

        )}
    </>
  );
}
import React from "react";
import { Link } from 'react-router-dom';


export default function ZugriffVerweigert() {

  
   
  
    return (
  
      <>
 
 <div>
      <h3>Zugriff zu diesem Bereich der Webseite ist für Besucher nicht gestattet.</h3>
      <hr />
      <Link to="/logout">Weiter zur Startseite...</Link>
    </div>
      </>
  
    );
  }
import logo from './logo.svg';
import './App.css';
import React from 'react';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import Menu from './komponente/Menu';
import Startseite from './komponente/Startseite';
import Bestellungen from './komponente/Bestellungen';
import Logout from './komponente/Logout';
import AdminProdukte from "./komponente/AdminProdukte";
import Datenschutz from "./komponente/Datenschutz";
import AdminAngebote from "./komponente/AdminAngebote";
import Anfragen from "./komponente/Anfragen";
import AdminImpressum from "./komponente/AdminImpressum";
import Impressum from "./komponente/Impressum";
import AdminSocialMedia from "./komponente/AdminSocialMedia";
import Kontakt from "./komponente/Kontakt";
import Warenkorb from "./komponente/Warenkorb";
import Angebote from "./komponente/Angebote";
import Login from "./komponente/Login";
import ZugriffVerweigert from "./komponente/ZugriffVerweigert";
import AdminDatenschutz from "./komponente/AdminDatenschutz";
function App() {
  return (
    <>
      <BrowserRouter>
        <Routes>

          <Route path="/" element={<Menu />}>
          <Route path="/" element={
            sessionStorage.getItem("adminStatus") === "1" ?(
              <Bestellungen/> 
          ):(
            <Startseite />   
          )}  />
          <Route path="/admin/produkte" element={<AdminProdukte />} />
          <Route path="/admin/agebote" element={<AdminAngebote/>} />
          <Route path="/admin/anfragen" element={<Anfragen />} />
          <Route path="/admin/socialMedia" element={<AdminSocialMedia />} />
          <Route path="/admin/impressum" element={<AdminImpressum/>} />
          <Route path="/admin/datenschutz" element={<AdminDatenschutz/>} />
          <Route path="/logout"     element={<Logout/>} />
          <Route path="/impressum" element={<Impressum />} />
          <Route path="/datenschutz" element={<Datenschutz/>} />       
          <Route path="/kontakt" element={<Kontakt/>} />
          <Route path="/warenkorb" element={<Warenkorb/>} />
          <Route path="/angebote" element={<Angebote/>} />
          <Route path="/login" element={<Login/>} />
          <Route path="/zugriffVerweigert" element={<ZugriffVerweigert/>} />
          </Route>

        </Routes>

      </BrowserRouter>

    </>

  );
}

export default App;
